PhraseExpress Portable Edition - Installation
---------------------------------------------

Bitte kopieren Sie das Verzeichnis "PhraseExpress" 
dieser Archivdatei in ein beliebiges 
Verzeichnis auf Ihrem USB Speicherstick.

Sie k�nnen das Programm von dort starten.

Bitte beachten Sie, das systembedingt einige Funktionen
beim Betrieb von einem USB Stick nicht unterst�tzt werden
k�nnen, weil diese einen Eingriff auf das Gastsystem 
erfordern w�rden (zum Beispiel das Outlook Add-In).

Weitere Informationen:
http://handbuch.phraseexpress.de#portable

--

Please copy the folder "PhraseExpress" of this ZIP archive 
into any directory on your USB memory device.

Please note that not all PhraseExpress features are 
available if running in portable mode as those would 
require changes on the guest computer (e.g. the Outlook Add-In).

Additional information:
http://manual.phraseexpress.com#portable


� 2002-2016 Bartels Media GmbH